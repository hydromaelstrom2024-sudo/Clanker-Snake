const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const scoreElement = document.getElementById("score");
const bestScoreElement = document.getElementById("bestScore");
const levelElement = document.getElementById("level");
const overlay = document.getElementById("overlay");
const overlayLabel = document.getElementById("overlayLabel");
const overlayTitle = document.getElementById("overlayTitle");
const overlayText = document.getElementById("overlayText");
const startButton = document.getElementById("startButton");
const pauseButton = document.getElementById("pauseButton");
const restartButton = document.getElementById("restartButton");
const soundButton = document.getElementById("soundButton");

const gridSize = 24;
const tileCount = canvas.width / gridSize;
const baseSpeed = 145;
const minimumSpeed = 62;

let snake;
let food;
let direction;
let queuedDirection;
let score;
let level;
let timer;
let running = false;
let paused = false;
let soundEnabled = true;
let bestScore = Number(localStorage.getItem("neonSnakeBest") || 0);
let audioContext;

bestScoreElement.textContent = bestScore;

function resetState() {
  snake = [
    { x: 12, y: 12 },
    { x: 11, y: 12 },
    { x: 10, y: 12 }
  ];
  direction = { x: 1, y: 0 };
  queuedDirection = { ...direction };
  score = 0;
  level = 1;
  scoreElement.textContent = score;
  levelElement.textContent = level;
  placeFood();
  draw();
}

function placeFood() {
  do {
    food = {
      x: Math.floor(Math.random() * tileCount),
      y: Math.floor(Math.random() * tileCount)
    };
  } while (snake?.some(part => part.x === food.x && part.y === food.y));
}

function startGame() {
  clearTimeout(timer);
  resetState();
  running = true;
  paused = false;
  overlay.classList.add("hidden");
  pauseButton.disabled = false;
  pauseButton.textContent = "Pause";
  scheduleTick();
  playTone(320, 0.08);
}

function scheduleTick() {
  clearTimeout(timer);
  if (!running || paused) return;
  const speed = Math.max(minimumSpeed, baseSpeed - (level - 1) * 10);
  timer = setTimeout(tick, speed);
}

function tick() {
  direction = queuedDirection;
  const head = {
    x: snake[0].x + direction.x,
    y: snake[0].y + direction.y
  };

  const hitWall =
    head.x < 0 ||
    head.y < 0 ||
    head.x >= tileCount ||
    head.y >= tileCount;

  const hitSelf = snake.some(part => part.x === head.x && part.y === head.y);

  if (hitWall || hitSelf) {
    endGame();
    return;
  }

  snake.unshift(head);

  if (head.x === food.x && head.y === food.y) {
    score += 10;
    level = Math.floor(score / 50) + 1;
    scoreElement.textContent = score;
    levelElement.textContent = level;
    placeFood();
    playTone(620 + level * 25, 0.06);

    if (score > bestScore) {
      bestScore = score;
      bestScoreElement.textContent = bestScore;
      localStorage.setItem("neonSnakeBest", String(bestScore));
    }
  } else {
    snake.pop();
  }

  draw();
  scheduleTick();
}

function endGame() {
  running = false;
  paused = false;
  clearTimeout(timer);
  pauseButton.disabled = true;
  playTone(145, 0.22);
  showOverlay("GAME OVER", `Score: ${score}`, "Press play to try again.", "Play again");
}

function togglePause() {
  if (!running) return;

  paused = !paused;
  pauseButton.textContent = paused ? "Resume" : "Pause";

  if (paused) {
    clearTimeout(timer);
    showOverlay("PAUSED", "Taking a breather?", "Press resume or the space bar.", "Resume");
  } else {
    overlay.classList.add("hidden");
    scheduleTick();
  }
}

function showOverlay(label, title, text, buttonText) {
  overlayLabel.textContent = label;
  overlayTitle.textContent = title;
  overlayText.textContent = text;
  startButton.textContent = buttonText;
  overlay.classList.remove("hidden");
}

function setDirection(next) {
  if (!running || paused) return;
  if (next.x === -direction.x && next.y === -direction.y) return;
  queuedDirection = next;
}

function drawRoundedRect(x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.roundRect(x, y, width, height, r);
}

function draw() {
  ctx.fillStyle = "#06100b";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = "rgba(92, 255, 164, 0.055)";
  ctx.lineWidth = 1;
  for (let i = 0; i <= tileCount; i++) {
    const position = i * gridSize;
    ctx.beginPath();
    ctx.moveTo(position, 0);
    ctx.lineTo(position, canvas.height);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(0, position);
    ctx.lineTo(canvas.width, position);
    ctx.stroke();
  }

  const foodCenterX = food.x * gridSize + gridSize / 2;
  const foodCenterY = food.y * gridSize + gridSize / 2;
  const glow = ctx.createRadialGradient(
    foodCenterX, foodCenterY, 2,
    foodCenterX, foodCenterY, gridSize
  );
  glow.addColorStop(0, "rgba(255, 92, 122, 0.9)");
  glow.addColorStop(1, "rgba(255, 92, 122, 0)");
  ctx.fillStyle = glow;
  ctx.fillRect(food.x * gridSize - gridSize / 2, food.y * gridSize - gridSize / 2, gridSize * 2, gridSize * 2);

  ctx.fillStyle = "#ff5c7a";
  ctx.beginPath();
  ctx.arc(foodCenterX, foodCenterY, gridSize * 0.28, 0, Math.PI * 2);
  ctx.fill();

  snake.forEach((part, index) => {
    const inset = index === 0 ? 2 : 3.2;
    const x = part.x * gridSize + inset;
    const y = part.y * gridSize + inset;
    const size = gridSize - inset * 2;

    const gradient = ctx.createLinearGradient(x, y, x + size, y + size);
    gradient.addColorStop(0, index === 0 ? "#c6ff5e" : "#65ffa7");
    gradient.addColorStop(1, index === 0 ? "#51ff9c" : "#1ddc7b");
    ctx.fillStyle = gradient;
    ctx.shadowColor = "rgba(81, 255, 156, 0.32)";
    ctx.shadowBlur = index === 0 ? 14 : 6;
    drawRoundedRect(x, y, size, size, index === 0 ? 7 : 6);
    ctx.fill();
    ctx.shadowBlur = 0;
  });

  const head = snake[0];
  if (head) {
    const baseX = head.x * gridSize;
    const baseY = head.y * gridSize;
    ctx.fillStyle = "#062114";

    let eyes;
    if (direction.x === 1) eyes = [[17, 7], [17, 16]];
    else if (direction.x === -1) eyes = [[7, 7], [7, 16]];
    else if (direction.y === -1) eyes = [[7, 7], [16, 7]];
    else eyes = [[7, 17], [16, 17]];

    eyes.forEach(([x, y]) => {
      ctx.beginPath();
      ctx.arc(baseX + x, baseY + y, 1.8, 0, Math.PI * 2);
      ctx.fill();
    });
  }
}

function playTone(frequency, duration) {
  if (!soundEnabled) return;

  try {
    audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gain = audioContext.createGain();

    oscillator.type = "sine";
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0.08, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + duration);

    oscillator.connect(gain);
    gain.connect(audioContext.destination);
    oscillator.start();
    oscillator.stop(audioContext.currentTime + duration);
  } catch {
    // Sound is optional; the game continues if audio is unavailable.
  }
}

const keyDirections = {
  ArrowUp: { x: 0, y: -1 },
  w: { x: 0, y: -1 },
  W: { x: 0, y: -1 },
  ArrowDown: { x: 0, y: 1 },
  s: { x: 0, y: 1 },
  S: { x: 0, y: 1 },
  ArrowLeft: { x: -1, y: 0 },
  a: { x: -1, y: 0 },
  A: { x: -1, y: 0 },
  ArrowRight: { x: 1, y: 0 },
  d: { x: 1, y: 0 },
  D: { x: 1, y: 0 }
};

document.addEventListener("keydown", event => {
  if (keyDirections[event.key]) {
    event.preventDefault();
    setDirection(keyDirections[event.key]);
  }

  if (event.code === "Space") {
    event.preventDefault();
    togglePause();
  }

  if (event.key === "Enter" && !running) {
    startGame();
  }
});

document.querySelectorAll("[data-direction]").forEach(button => {
  button.addEventListener("pointerdown", event => {
    event.preventDefault();
    const directionName = button.dataset.direction;
    const directions = {
      up: { x: 0, y: -1 },
      down: { x: 0, y: 1 },
      left: { x: -1, y: 0 },
      right: { x: 1, y: 0 }
    };
    setDirection(directions[directionName]);
  });
});

let touchStart = null;
canvas.addEventListener("touchstart", event => {
  const touch = event.changedTouches[0];
  touchStart = { x: touch.clientX, y: touch.clientY };
}, { passive: true });

canvas.addEventListener("touchend", event => {
  if (!touchStart) return;
  const touch = event.changedTouches[0];
  const dx = touch.clientX - touchStart.x;
  const dy = touch.clientY - touchStart.y;

  if (Math.max(Math.abs(dx), Math.abs(dy)) > 24) {
    if (Math.abs(dx) > Math.abs(dy)) {
      setDirection(dx > 0 ? { x: 1, y: 0 } : { x: -1, y: 0 });
    } else {
      setDirection(dy > 0 ? { x: 0, y: 1 } : { x: 0, y: -1 });
    }
  }

  touchStart = null;
}, { passive: true });

startButton.addEventListener("click", () => {
  if (running && paused) {
    togglePause();
  } else {
    startGame();
  }
});

pauseButton.addEventListener("click", togglePause);
restartButton.addEventListener("click", startGame);

soundButton.addEventListener("click", () => {
  soundEnabled = !soundEnabled;
  soundButton.textContent = soundEnabled ? "🔊" : "🔇";
  soundButton.setAttribute("aria-label", soundEnabled ? "Mute sound" : "Enable sound");
});

resetState();
