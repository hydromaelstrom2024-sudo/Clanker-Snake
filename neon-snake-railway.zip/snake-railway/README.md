# Neon Snake

A responsive Snake game built with HTML, CSS, and JavaScript. It includes keyboard controls, mobile buttons, pause/resume, increasing speed, sound effects, and a locally saved high score.

## Run locally

You need Node.js 20 or newer.

```bash
npm start
```

Open `http://localhost:3000`.

## Upload to GitHub

1. Create a new empty repository on GitHub. A good name is `neon-snake`.
2. Extract this ZIP.
3. Open a terminal inside the extracted folder.
4. Run:

```bash
git init
git add .
git commit -m "Initial Snake game"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/neon-snake.git
git push -u origin main
```

You can also upload the extracted files with GitHub's **Add file → Upload files** option.

## Deploy on Railway

1. Sign in to Railway and choose **New Project**.
2. Select **Deploy from GitHub repo**.
3. Connect GitHub if Railway asks.
4. Select your `neon-snake` repository.
5. Click **Deploy Now**.
6. After deployment, open the service's **Settings → Networking**.
7. Click **Generate Domain**.

Railway detects the root `Dockerfile` automatically. The Node server listens on `0.0.0.0` and uses Railway's `PORT` environment variable.

No database or custom environment variables are required.
